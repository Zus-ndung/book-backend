package master.bookapp;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.List;

import adapters.BookAdapter;
import helper.SecurePreferencesHelper;
import network.ApiClient;
import network.model.Book;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class InforActivity extends AppCompatActivity implements BookAdapter.OnItemClickListener {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
        ImageButton BackTo = findViewById(R.id.button_back);
        BackTo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Button button_read_now = findViewById(R.id.button_read_now);
        button_read_now.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(InforActivity.this, ReadBookActivity.class);
                startActivity(intent);
            }
        });

        try {
            showBook();
        } catch (GeneralSecurityException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            Toast.makeText(this, "Error get categories", Toast.LENGTH_SHORT).show();
            throw new RuntimeException(e);
        }

        try {
            getPopularBooks();
        } catch (GeneralSecurityException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    protected void showBook() throws GeneralSecurityException, IOException {
        SecurePreferencesHelper securePreferencesHelper = new SecurePreferencesHelper(this);
        String token = securePreferencesHelper.getData("auth_token");
        String bookId = securePreferencesHelper.getData("book_id");
        Log.i("INFO", bookId);
        Context context = this;
        ApiClient.getClient().GetDetail(token, bookId).enqueue(new Callback<Book>() {
            @Override
            public void onResponse(Call<Book> call, Response<Book> response) {
                if (response.isSuccessful()){
                    Book book= response.body();
                    assert book != null;
                    Glide.with(InforActivity.this)
                            .load(book.getCover_img_url())
                            .into((android.widget.ImageView) findViewById(R.id.image_book));
                    TextView desc = findViewById(R.id.text_short_description);
                    TextView title = findViewById(R.id.text_book_title);
                    TextView rating = findViewById(R.id.ratingText1);
                    TextView reading = findViewById(R.id.reading_number);
                    TextView author = findViewById(R.id.text_author);
                    desc.setText(book.getDesc());
                    title.setText(book.getTitle());
                    rating.setText(String.valueOf(book.getAvg_rate()));
                    reading.setText(String.valueOf("(" + book.getNum_review() + " Reviews)"));
                    author.setText(book.getAuthor());
                } else {
                    Toast.makeText(context, "Can not get book detail", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Book> call, Throwable t) {
                Toast.makeText(context, "Can not get book detail", Toast.LENGTH_SHORT).show();
            }
        });
    }
    protected void getPopularBooks() throws GeneralSecurityException, IOException {
        SecurePreferencesHelper securePreferencesHelper = new SecurePreferencesHelper(this);
        String token = securePreferencesHelper.getData("auth_token");
        Context context = this;
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        ApiClient.getClient().GetPopularBook(token).enqueue(new Callback<List<Book>>() {
            @Override
            public void onResponse(Call<List<Book>> call, Response<List<Book>> response) {
                if (response.isSuccessful()){
                    List<Book> books= response.body();
                    BookAdapter adapter = new BookAdapter(books, InforActivity.this);
                    try {
                        recyclerView.setAdapter(adapter);
                    } catch (RuntimeException e) {
                        throw new RuntimeException(e);
                    }
                } else {
                    Toast.makeText(context, "Can not get popular books", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Book>> call, Throwable t) {
                Toast.makeText(context, "Can not get popular books", Toast.LENGTH_SHORT).show();
            }
        });
    }
    @Override
    public void onItemClick(Book item) {
        String book_id = item.getBook_id();
        try {
            SecurePreferencesHelper securePreferencesHelper = new SecurePreferencesHelper(this);
            securePreferencesHelper.saveData("book_id", book_id);
            Intent intent = new Intent(InforActivity.this, InforActivity.class);
            startActivity(intent);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (GeneralSecurityException e) {
            throw new RuntimeException(e);
        }
    }
}
