package master.bookapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.atomic.AtomicBoolean;

import network.ApiClient;
import network.model.LoginResponse;
import network.model.SignUpRequest;
import network.model.SignUpResponse;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {

    private EditText Email, Password, ConfirmPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        EditText emailEditText = findViewById(R.id.RegisterEmail);
        EditText passwordEditText = findViewById(R.id.RegisterPassword);
        EditText confirmPasswordEditText = findViewById(R.id.RegisterConfirmPassword);
        EditText displayNameEditText = findViewById(R.id.Username);
        Button btnRegister = findViewById(R.id.btnRegister);
        TextView BackToLogin = findViewById(R.id.BackToLogin);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isRegister = SignUpAction(
                        emailEditText, passwordEditText, confirmPasswordEditText, displayNameEditText
                );
            }
        });

        BackToLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    protected boolean SignUpAction(
            EditText emailEditText, EditText passwordEditText,
            EditText confirmPasswordEditText, EditText displayNameEditText
    ){
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        String confirmPassword = confirmPasswordEditText.getText().toString().trim();
        String displayName = displayNameEditText.getText().toString().trim();
        if (email.isEmpty()) {
            Toast.makeText(emailEditText.getContext(), "Email must be required", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(emailEditText.getContext(), "Email invalid", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (password.isEmpty()) {
            Toast.makeText(passwordEditText.getContext(), "Password must be required", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (confirmPassword.isEmpty()) {
            Toast.makeText(passwordEditText.getContext(), "Confirm Password must be required", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (displayName.isEmpty()) {
            Toast.makeText(passwordEditText.getContext(), "Display Name must be required", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!password.equals(confirmPassword)) {
            Toast.makeText(passwordEditText.getContext(), "Password and Confirm Password must be similar", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(emailEditText.getContext(), "Email invalid", Toast.LENGTH_SHORT).show();
            return false;
        }

        AtomicBoolean isAuth = new AtomicBoolean(false);
        SignUpRequest signupRequest = new SignUpRequest(
            email,
            password,
            displayName
        );
        try {
            ApiClient.getClient().SignUp(signupRequest).enqueue(new Callback<SignUpResponse>() {
                @Override
                public void onResponse(@NonNull Call<SignUpResponse> call, @NonNull Response<SignUpResponse> response) {
                    if (response.isSuccessful()) {
                        SignUpResponse signupResponse = response.body();
                        assert signupResponse != null;
                        Toast.makeText(RegisterActivity.this, "Registration success: " + signupResponse.getMsg(), Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(RegisterActivity.this, "Registration failed: Username already exists", Toast.LENGTH_SHORT).show();
                        isAuth.set(false);
                    }
                }

                @Override
                public void onFailure(@NonNull Call<SignUpResponse> call, @NonNull Throwable t) {
                    Log.e("SignupError", t.getMessage() != null ? t.getMessage() : "Unknown error");
                    Toast.makeText(RegisterActivity.this, "Internal Error", Toast.LENGTH_SHORT).show();
                    isAuth.set(false);
                }
            });
        } catch (RuntimeException e) {
            throw new RuntimeException(e);
        }
        return isAuth.get();
    }
}
