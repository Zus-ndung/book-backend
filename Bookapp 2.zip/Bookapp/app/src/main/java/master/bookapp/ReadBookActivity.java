package master.bookapp;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.security.GeneralSecurityException;

import helper.SecurePreferencesHelper;
import network.ApiClient;
import network.model.BookRead;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ReadBookActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read);
        ImageButton BackTo = findViewById(R.id.button_back);
        BackTo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        try {
            getBookText();
        } catch (GeneralSecurityException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            Toast.makeText(this, "Error get categories", Toast.LENGTH_SHORT).show();
            throw new RuntimeException(e);
        }
    }
    protected void getBookText() throws GeneralSecurityException, IOException {
        SecurePreferencesHelper securePreferencesHelper = new SecurePreferencesHelper(this);
        String token = securePreferencesHelper.getData("auth_token");
        String bookId = securePreferencesHelper.getData("book_id");
        Log.i("INFO", bookId);
        Context context = this;
        ApiClient.getClient().GetBookText(token, bookId).enqueue(new Callback<BookRead>() {
            @Override
            public void onResponse(Call<BookRead> call, Response<BookRead> response) {
                if (response.isSuccessful()){
                    BookRead book= response.body();
                    assert book != null;
                    TextView title = findViewById(R.id.title);
                    TextView text = findViewById(R.id.text);
                    title.setText(book.getTitle());
                    text.setText(book.getText());
                } else {
                    Toast.makeText(context, "Can not get book detail", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(Call<BookRead> call, Throwable t) {
                Toast.makeText(context, "Can not get book detail", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
