package master.bookapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.List;

import adapters.BookAdapter;
import adapters.CategoryAdapter;
import helper.AuthUtils;
import helper.SecurePreferencesHelper;
import network.ApiClient;
import network.model.Book;
import network.model.Category;
import network.model.User;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements BookAdapter.OnItemClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AuthUtils.redirectToLoginIfNotLoggedIn(this);
        TextView usernameEditText = findViewById(R.id.User);

        findViewById(R.id.search).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SearchActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.user).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, UserActivity.class);
                startActivity(intent);
            }
        });

        try {
            setUsername(usernameEditText);
        } catch (Exception e) {
            Toast.makeText(this, "Error get user was login", Toast.LENGTH_SHORT).show();
            throw new RuntimeException(e);
        }

        try {
            getPopularBooks();
        } catch (GeneralSecurityException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            Toast.makeText(this, "Error get popular books", Toast.LENGTH_SHORT).show();
            throw new RuntimeException(e);
        }

        try {
            getBookMaxRate();
        } catch (GeneralSecurityException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            Toast.makeText(this, "Error get recommend books", Toast.LENGTH_SHORT).show();
            throw new RuntimeException(e);
        }
    }

    protected void setUsername(TextView username) throws Exception {
        User user = AuthUtils.getMe(this);
        username.setText(user.getDisplay_name());
    }

    protected void getPopularBooks() throws GeneralSecurityException, IOException {
        SecurePreferencesHelper securePreferencesHelper = new SecurePreferencesHelper(this);
        String token = securePreferencesHelper.getData("auth_token");
        Context context = this;
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        ApiClient.getClient().GetPopularBook(token).enqueue(new Callback<List<Book>>() {
            @Override
            public void onResponse(Call<List<Book>> call, Response<List<Book>> response) {
                if (response.isSuccessful()){
                    List<Book> books= response.body();
                    BookAdapter adapter = new BookAdapter(books, MainActivity.this);
                    try {
                        recyclerView.setAdapter(adapter);
                    } catch (RuntimeException e) {
                        throw new RuntimeException(e);
                    }
                } else {
                    Toast.makeText(context, "Can not get popular books", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Book>> call, Throwable t) {
                Toast.makeText(context, "Can not get popular books", Toast.LENGTH_SHORT).show();
            }
        });
    }

    protected void getBookMaxRate() throws GeneralSecurityException, IOException {
        SecurePreferencesHelper securePreferencesHelper = new SecurePreferencesHelper(this);
        String token = securePreferencesHelper.getData("auth_token");
        Context context = this;
        RecyclerView recyclerView = findViewById(R.id.recyclerViewRecomment);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        ApiClient.getClient().GetRecommendBook(token).enqueue(new Callback<List<Book>>() {
            @Override
            public void onResponse(Call<List<Book>> call, Response<List<Book>> response) {
                if (response.isSuccessful()){
                    List<Book> books= response.body();
                    BookAdapter adapter = new BookAdapter(books, MainActivity.this);
                    try {
                        recyclerView.setAdapter(adapter);
                    } catch (RuntimeException e) {
                        throw new RuntimeException(e);
                    }
                } else {
                    Toast.makeText(context, "Can not get popular books", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Book>> call, Throwable t) {
                Toast.makeText(context, "Can not get popular books", Toast.LENGTH_SHORT).show();
            }
        });
    }

//    protected void getCategories() throws GeneralSecurityException, IOException {
//        SecurePreferencesHelper securePreferencesHelper = new SecurePreferencesHelper(this);
//        String token = securePreferencesHelper.getData("auth_token");
//        Context context = this;
//        RecyclerView recyclerView = findViewById(R.id.recyclerViewCategory);
//        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
//        ApiClient.getClient().GetCategory(token).enqueue(new Callback<List<Category>>() {
//            @Override
//            public void onResponse(Call<List<Category>> call, Response<List<Category>> response) {
//                if (response.isSuccessful()){
//                    List<Category> categories= response.body();
//                    CategoryAdapter adapter = new CategoryAdapter(categories, MainActivity.this);
//                    try {
//                        recyclerView.setAdapter(adapter);
//                    } catch (RuntimeException e) {
//                        throw new RuntimeException(e);
//                    }
//                } else {
//                    Toast.makeText(context, "Can not get categories book", Toast.LENGTH_SHORT).show();
//                }
//            }
//
//            @Override
//            public void onFailure(Call<List<Category>> call, Throwable t) {
//                Toast.makeText(context, "Can not get categories book", Toast.LENGTH_SHORT).show();
//            }
//        });
//    }

    @Override
    public void onItemClick(Book item) {
        String book_id = item.getBook_id();
        try {
            SecurePreferencesHelper securePreferencesHelper = new SecurePreferencesHelper(this);
            securePreferencesHelper.saveData("book_id", book_id);
            Intent intent = new Intent(MainActivity.this, InforActivity.class);
            startActivity(intent);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (GeneralSecurityException e) {
            throw new RuntimeException(e);
        }
    }
}