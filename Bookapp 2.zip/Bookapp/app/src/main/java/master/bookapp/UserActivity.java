package master.bookapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.security.GeneralSecurityException;

import helper.SecurePreferencesHelper;
import network.model.User;

public class UserActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        SecurePreferencesHelper securePreferencesHelper = null;
        try {
            securePreferencesHelper = new SecurePreferencesHelper(this);
        } catch (GeneralSecurityException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        String username = securePreferencesHelper.getData("display_name");
        TextView usernameTextView = findViewById(R.id.Username);
        usernameTextView.setText(username);

        findViewById(R.id.search).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(UserActivity.this, SearchActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.home).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(UserActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
        findViewById(R.id.btnEditProfile).setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View view) {
                        Logout();
                    }
                }
        );
    }

    protected void Logout(){
        SecurePreferencesHelper securePreferencesHelper = null;
        try {
            securePreferencesHelper = new SecurePreferencesHelper(this);
        } catch (GeneralSecurityException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        securePreferencesHelper.removeData("auth_token");
        Intent intent = new Intent(UserActivity.this, LoginActivity.class);
        startActivity(intent);
    }
}
