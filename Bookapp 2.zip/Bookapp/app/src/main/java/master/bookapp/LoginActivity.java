package master.bookapp;

import static master.bookapp.R.id.Forgotpw;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.concurrent.atomic.AtomicBoolean;

import helper.AuthUtils;
import network.ApiClient;
import network.model.LoginResponse;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button btnLogin = findViewById(R.id.btnLogin);
        TextView CreateAccount = findViewById(R.id.CreateAccount);
        TextView forgot= findViewById(Forgotpw);
        EditText emailEditText = findViewById(R.id.etEmail);
        EditText passwordEditText = findViewById(R.id.etPassword);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginAction(emailEditText, passwordEditText, v.getContext());
            }
        });

        forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, ForgotActivity.class);
                startActivity(intent);
            }
        });

        CreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }

    protected void LoginAction(EditText emailEditText, EditText passwordEditText, Context context){
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (email.isEmpty()) {
            Toast.makeText(emailEditText.getContext(), "Email must be required", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(emailEditText.getContext(), "Email invalid", Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.isEmpty()) {
            Toast.makeText(passwordEditText.getContext(), "Password must be required", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            ApiClient.getClient().SignIn(email, password).enqueue(new Callback<LoginResponse>() {
                @Override
                public void onResponse(@NonNull Call<LoginResponse> call, @NonNull Response<LoginResponse> response) {
                    if (response.isSuccessful()) {
                        LoginResponse signupResponse = response.body();
                        assert signupResponse != null;
                        Toast.makeText(LoginActivity.this, "Login Successfully by: " + email, Toast.LENGTH_SHORT).show();
                        try {
                            AuthUtils.saveAccessToken(context, signupResponse.getAccess_token());
                        } catch (GeneralSecurityException | IOException e) {
                            Toast.makeText(LoginActivity.this, "Internal Error", Toast.LENGTH_SHORT).show();
                            throw new RuntimeException(e);
                        }
                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(LoginActivity.this, "Login Failed: Invalid email or password", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(@NonNull Call<LoginResponse> call, @NonNull Throwable t) {
                    Log.e("SignupError", t.getMessage() != null ? t.getMessage() : "Unknown error");
                    Toast.makeText(LoginActivity.this, "Internal Error", Toast.LENGTH_SHORT).show();
                }
            });
        } catch (RuntimeException e) {
            throw new RuntimeException(e);
        }
    }
}