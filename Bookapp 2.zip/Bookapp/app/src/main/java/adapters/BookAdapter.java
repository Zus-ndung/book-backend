package adapters;
import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

import master.bookapp.R;
import network.model.Book;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.ItemViewHolder> {

    private final List<Book> items;
    private final OnItemClickListener listener;

    public BookAdapter(List<Book> items, OnItemClickListener listener) {
        this.items = items;
        this.listener = listener;
    }


    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_popular_book, parent, false);
        return new ItemViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        Book item = items.get(position);
        holder.bookTitle.setText(item.getTitle());
        holder.bookRating.setText(String.valueOf(item.getAvg_rate()) + "★");
        Glide.with(holder.bookCover.getContext())
                .load(item.getCover_img_url())
//                .placeholder(R.drawable.placeholder) // Ảnh tạm trong khi tải
//                .error(R.drawable.error) // Ảnh lỗi nếu tải thất bại
                .into(holder.bookCover);
//        holder.bookCover.setImageURI(item.getCover_img_url());
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(item);  // Gọi sự kiện click và truyền dữ liệu item
            }
        });

    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView bookTitle;
        TextView bookRating;
        ImageView bookCover;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            bookTitle = itemView.findViewById(R.id.bookTitle);
            bookRating = itemView.findViewById(R.id.bookRating);
            bookCover = itemView.findViewById(R.id.bookCover);
        }
    }

    public interface OnItemClickListener {
        void onItemClick(Book item);
    }

}
