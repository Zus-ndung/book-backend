package adapters;
import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

import master.bookapp.R;
import network.model.Book;

public class BookSearchAdapter extends RecyclerView.Adapter<BookSearchAdapter.ItemViewHolder> {

    private final List<Book> items;
    private final OnItemClickListener listener;

    public BookSearchAdapter(List<Book> items, OnItemClickListener listener) {
        this.items = items;
        this.listener = listener;
    }


    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_book_search, parent, false);
        return new ItemViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        Book item = items.get(position);
        holder.bookTitle.setText(item.getTitle());
        holder.bookRating.setText(String.valueOf(item.getAvg_rate()));
        holder.bookDesc.setText(item.getDesc());
        holder.bookAuthor.setText(item.getAuthor());
        Glide.with(holder.bookCover.getContext())
                .load(item.getCover_img_url())
//                .placeholder(R.drawable.placeholder) // Ảnh tạm trong khi tải
//                .error(R.drawable.error) // Ảnh lỗi nếu tải thất bại
                .into(holder.bookCover);
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(item);  // Gọi sự kiện click và truyền dữ liệu item
            }
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView bookTitle;
        TextView bookAuthor;
        ImageView bookCover;

        TextView bookRating;

        TextView bookDesc;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            bookTitle = itemView.findViewById(R.id.title);
            bookAuthor = itemView.findViewById(R.id.author);
            bookCover = itemView.findViewById(R.id.image);
            bookRating = itemView.findViewById(R.id.rating);
            bookDesc = itemView.findViewById(R.id.desc);
        }
    }

    public interface OnItemClickListener {
        void onItemClick(Book item);
    }
}
