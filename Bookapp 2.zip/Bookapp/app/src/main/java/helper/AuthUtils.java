package helper;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import java.io.IOException;
import java.security.GeneralSecurityException;

import master.bookapp.LoginActivity;
import master.bookapp.MainActivity;
import network.ApiClient;
import network.model.LoginResponse;
import network.model.User;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AuthUtils {

    public static boolean isUserLoggedIn(Context context) {
        try {
            SecurePreferencesHelper securePreferencesHelper = new SecurePreferencesHelper(context);

            String token = securePreferencesHelper.getData("auth_token");
            if (token == null || token.isEmpty()){
                return false;
            }
            ApiClient.getClient().GetMe("Bearer " + token).enqueue(new Callback<User>() {
                @Override
                public void onResponse(Call<User> call, Response<User> response) {
                    if (response.isSuccessful()) {
                        User user = response.body();
                        assert user != null;
                        securePreferencesHelper.saveData("username", user.getUsername());
                        securePreferencesHelper.saveData("display_name", user.getDisplay_name());
                        securePreferencesHelper.saveData("user_id", user.getUser_id());
                    } else {
                        Toast.makeText(context, "Unauthenticated. Login again", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(context, LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        context.startActivity(intent);
                    }
                }

                @Override
                public void onFailure(Call<User> call, Throwable t) {
                    Log.e("SignupError", t.getMessage() != null ? t.getMessage() : "Unknown error");
                    Toast.makeText(context, "Internal Error", Toast.LENGTH_SHORT).show();
                }
            });
            return true;
        } catch (Exception e) {
            Log.e("Auth Utils", "isUserLoggedIn: " + e.getMessage());
            return false;
        }
    }

    public static Boolean redirectToLoginIfNotLoggedIn(Context context) {
        if (!isUserLoggedIn(context)) {
            Intent intent = new Intent(context, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            context.startActivity(intent);
            return false;
        }
        return true;
    }

    public static void saveAccessToken(Context context, String accessToken) throws GeneralSecurityException, IOException {
        try {
            SecurePreferencesHelper securePreferencesHelper = new SecurePreferencesHelper(context);
            securePreferencesHelper.saveData("auth_token", accessToken);
        } catch (Exception e) {
            throw e;
        }
    }
    public static User getMe(Context context) throws Exception {
        SecurePreferencesHelper securePreferencesHelper = new SecurePreferencesHelper(context);
        String username = securePreferencesHelper.getData("username");
        String display_name = securePreferencesHelper.getData("display_name");
        String user_id = securePreferencesHelper.getData("user_id");
        return new User(user_id, username, display_name);
    }
}
