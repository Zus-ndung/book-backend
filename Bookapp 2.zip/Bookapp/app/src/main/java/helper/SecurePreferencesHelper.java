package helper;

import android.content.Context;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import java.io.IOException;
import java.security.GeneralSecurityException;

public class SecurePreferencesHelper {

    private static final String PREFS_NAME = "secure_prefs";
    private final EncryptedSharedPreferences encryptedSharedPreferences;

    public SecurePreferencesHelper(Context context) throws GeneralSecurityException, IOException {
        // Tạo MasterKey
        MasterKey masterKey = new MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build();

        // Tạo EncryptedSharedPreferences
        encryptedSharedPreferences = (EncryptedSharedPreferences) EncryptedSharedPreferences.create(
                context,
                PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        );
    }

    public void saveData(String key, String value) {
        encryptedSharedPreferences.edit()
                .putString(key, value)
                .apply();
    }

    public String getData(String key) {
        return encryptedSharedPreferences.getString(key, null);
    }

    public void removeData(String key) {
        encryptedSharedPreferences.edit()
                .remove(key)
                .apply();
    }

    public EncryptedSharedPreferences getEncryptedSharedPreferences() {
        return encryptedSharedPreferences;
    }
}
