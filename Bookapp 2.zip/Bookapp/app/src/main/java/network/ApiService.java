package network;

import java.util.List;

import network.model.Book;
import network.model.BookRead;
import network.model.Category;
import network.model.LoginRequest;
import network.model.LoginResponse;
import network.model.SignUpRequest;
import network.model.SignUpResponse;
import network.model.User;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ApiService {
    @Headers("Content-Type: application/json")
    @POST("/auth/signup")
    Call<SignUpResponse> SignUp(@Body SignUpRequest signUpRequest);

    @Headers("Content-Type: application/x-www-form-urlencoded")
    @FormUrlEncoded
    @POST("/auth/login")
    Call<LoginResponse> SignIn(@Field("username") String email,
    @Field("password") String password);


    @GET("/auth/me")
    Call<User>GetMe(@Header("Authorization") String token);

    @GET("/book/popular")
    Call<List<Book>> GetPopularBook(@Header("Authorization") String token);

    @GET("/book/categories")
    Call<List<Category>> GetCategory(@Header("Authorization") String token);

    @GET("/book/detail")
    Call<Book> GetDetail(@Header("Authorization") String token,@Query("book_id") String bookId);

    @GET("/book/text")
    Call<BookRead> GetBookText(@Header("Authorization") String token, @Query("book_id") String bookId);

    @GET("/book/search")
    Call<List<Book>> SearchBook(@Header("Authorization") String token, @Query("title") String name);

    @GET("/book/category")
    Call<List<Book>> GetBookByCategory(@Header("Authorization") String token, @Query("name") String name);

    @GET("/book/recommend")
    Call<List<Book>> GetRecommendBook(@Header("Authorization") String token);

}
