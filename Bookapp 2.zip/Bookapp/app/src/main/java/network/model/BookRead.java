package network.model;

public class BookRead {
    String title;
    String text;

    public BookRead(String title, String text){
        this.text = text;
        this.title = title;
    }

    public String getText(){
        return text;
    }

    public String getTitle(){
        return title;
    }
}
