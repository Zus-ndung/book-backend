package network.model;

public class Category {
    String name;

    public Category(String name){
        this.name = name;
    }

    public String getName(){
        return this.name;
    }
}
