package network.model;

import android.net.Uri;

import java.util.List;

public class Book {
    String book_id;
    List<String> author;
    List<String> genre;
    String isbn;
    String book_format;
    String cover_img_url;
    Integer num_review;
    Integer num_rate;
    Float avg_rate;
    String title;
    String desc;

    Integer num_page;

    public Book(String book_id, List<String> author, List<String> genre, String isbn, String book_format,
                String cover_img_url, Integer num_review, Integer num_page,
                Integer num_rate, Float avg_rate
                ){
        this.book_id = book_id;
        this.author = author;
        this.genre = genre;
        this.isbn = isbn;
        this.book_format = book_format;
        this.cover_img_url = cover_img_url;
        this.num_review = num_review;
        this.num_page = num_page;
        this.num_rate = num_rate;
        this.avg_rate = avg_rate;
    }

    public String getTitle(){
        return this.title;
    }
    public String getDesc() {
        return this.desc;
    }

    public Uri getCover_img_url() {
        return Uri.parse(this.cover_img_url);
    }

    public Float getAvg_rate() {
        return avg_rate;
    }

    public String getAuthor() {
        return String.join(", ", this.author);
    }

    public Integer getNum_review() {
        return num_review;
    }
    public String getBook_id(){
        return book_id;
    }
}
