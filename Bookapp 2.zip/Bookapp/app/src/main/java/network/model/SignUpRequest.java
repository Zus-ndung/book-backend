package network.model;

public class SignUpRequest {
    String username;
    String password;
    String display_name;
    String type_authen;

    public SignUpRequest(String username, String password, String display_name){
        this.username = username;
        this.password = password;
        this.display_name = display_name;
        this.type_authen = "Bearer";
    }

}
