package network.model;

public class LoginResponse {

    String access_token;
    String token_type;

    public LoginResponse(String access_token, String token_type, String detail){
        this.access_token = access_token;
        this.token_type = token_type;
    }

    public String getAccess_token(){
        return this.access_token;
    }

    public String getToken_type(){
        return this.token_type;
    }
}
