package network.model;

public class SignUpResponse {
    String msg;

    public SignUpResponse(String msg){
        this.msg = msg;
    }
    public String getMsg(){
        return this.msg;
    }
}
