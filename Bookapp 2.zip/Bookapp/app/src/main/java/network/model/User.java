package network.model;

public class User {
    String user_id;
    String username;
    String display_name;

    public User(String user_id, String username, String display_name){
        this.user_id = user_id;
        this.username = username;
        this.display_name = display_name;
    }

    public String getUsername() {
        return this.username;
    }

    public String getDisplay_name() {
        return this.display_name;
    }

    public String getUser_id() {
        return this.user_id;
    }
}
